
Project RUTDevKit:
PCB dimensions 82x60mm.
2 Layers.
Thickness: 1.55 mm. FR4
Mask color : Blue.
Silkscreen color: White.
Finish: RoHS PB Free
